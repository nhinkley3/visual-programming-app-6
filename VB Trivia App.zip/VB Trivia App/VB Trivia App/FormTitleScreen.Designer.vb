﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormTitleScreen
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ButtonPlay = New System.Windows.Forms.Button()
        Me.ButtonSettings = New System.Windows.Forms.Button()
        Me.ButtonCustomQuestions = New System.Windows.Forms.Button()
        Me.ButtonAbout = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Harrington", 28.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.DarkGreen
        Me.Label1.Location = New System.Drawing.Point(152, 95)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(541, 56)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Visual Basic Trivia App"
        '
        'ButtonPlay
        '
        Me.ButtonPlay.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.ButtonPlay.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.ButtonPlay.BackColor = System.Drawing.Color.White
        Me.ButtonPlay.Font = New System.Drawing.Font("Harrington", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonPlay.ForeColor = System.Drawing.Color.DarkGreen
        Me.ButtonPlay.Location = New System.Drawing.Point(208, 192)
        Me.ButtonPlay.Name = "ButtonPlay"
        Me.ButtonPlay.Size = New System.Drawing.Size(435, 50)
        Me.ButtonPlay.TabIndex = 1
        Me.ButtonPlay.Text = "Play"
        Me.ButtonPlay.UseVisualStyleBackColor = False
        '
        'ButtonSettings
        '
        Me.ButtonSettings.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.ButtonSettings.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.ButtonSettings.BackColor = System.Drawing.Color.White
        Me.ButtonSettings.Font = New System.Drawing.Font("Harrington", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonSettings.ForeColor = System.Drawing.Color.DarkGreen
        Me.ButtonSettings.Location = New System.Drawing.Point(208, 248)
        Me.ButtonSettings.Name = "ButtonSettings"
        Me.ButtonSettings.Size = New System.Drawing.Size(435, 50)
        Me.ButtonSettings.TabIndex = 2
        Me.ButtonSettings.Text = "Settings"
        Me.ButtonSettings.UseVisualStyleBackColor = False
        '
        'ButtonCustomQuestions
        '
        Me.ButtonCustomQuestions.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.ButtonCustomQuestions.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.ButtonCustomQuestions.BackColor = System.Drawing.Color.White
        Me.ButtonCustomQuestions.Font = New System.Drawing.Font("Harrington", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonCustomQuestions.ForeColor = System.Drawing.Color.DarkGreen
        Me.ButtonCustomQuestions.Location = New System.Drawing.Point(208, 304)
        Me.ButtonCustomQuestions.Name = "ButtonCustomQuestions"
        Me.ButtonCustomQuestions.Size = New System.Drawing.Size(435, 50)
        Me.ButtonCustomQuestions.TabIndex = 3
        Me.ButtonCustomQuestions.Text = "Custom Questions"
        Me.ButtonCustomQuestions.UseVisualStyleBackColor = False
        '
        'ButtonAbout
        '
        Me.ButtonAbout.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.ButtonAbout.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.ButtonAbout.BackColor = System.Drawing.Color.White
        Me.ButtonAbout.Font = New System.Drawing.Font("Harrington", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ButtonAbout.ForeColor = System.Drawing.Color.DarkGreen
        Me.ButtonAbout.Location = New System.Drawing.Point(208, 360)
        Me.ButtonAbout.Name = "ButtonAbout"
        Me.ButtonAbout.Size = New System.Drawing.Size(435, 50)
        Me.ButtonAbout.TabIndex = 4
        Me.ButtonAbout.Text = "About"
        Me.ButtonAbout.UseVisualStyleBackColor = False
        '
        'Label3
        '
        Me.Label3.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Harrington", 19.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.DarkGreen
        Me.Label3.Location = New System.Drawing.Point(340, 607)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(192, 40)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Version 0.1"
        '
        'FormTitleScreen
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(874, 656)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.ButtonAbout)
        Me.Controls.Add(Me.ButtonCustomQuestions)
        Me.Controls.Add(Me.ButtonSettings)
        Me.Controls.Add(Me.ButtonPlay)
        Me.Controls.Add(Me.Label1)
        Me.Name = "FormTitleScreen"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Visual Basic Trivia App"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents ButtonPlay As Button
    Friend WithEvents ButtonSettings As Button
    Friend WithEvents ButtonCustomQuestions As Button
    Friend WithEvents ButtonAbout As Button
    Friend WithEvents Label3 As Label
End Class
