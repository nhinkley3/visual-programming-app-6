﻿Public Class FormAbout
    'Start - Nick'
    Private Sub ButtonBack_Click(sender As Object, e As EventArgs) Handles ButtonBack.Click
        Me.Close()
    End Sub
    'End - Nick'
End Class