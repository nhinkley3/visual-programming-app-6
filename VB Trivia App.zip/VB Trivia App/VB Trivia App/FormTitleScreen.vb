﻿Public Class FormTitleScreen
    'Start - Nick'
    Private Sub ButtonPlay_Click(sender As Object, e As EventArgs) Handles ButtonPlay.Click
        'This can either open a bridge form to select difficulty or the play form with a message box.'
        'FormPlay.Show()
    End Sub

    Private Sub ButtonSettings_Click(sender As Object, e As EventArgs) Handles ButtonSettings.Click
        'FormSettings.Show()
    End Sub

    Private Sub ButtonCustomQuestions_Click(sender As Object, e As EventArgs) Handles ButtonCustomQuestions.Click
        'FormCustomQuestions.Show()
    End Sub

    Private Sub ButtonAbout_Click(sender As Object, e As EventArgs) Handles ButtonAbout.Click
        FormAbout.Show()
    End Sub
    'End - Nick'
End Class
